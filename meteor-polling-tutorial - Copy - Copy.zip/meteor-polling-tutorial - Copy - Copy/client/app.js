Router.configure({
  layoutTemplate: 'main'
});

Template.user.helpers({
  currentUser: Meteor.user,
  polls: function() {
    return Polls.find();
  }
  
});

Template.pollCount.helpers({
  'totalPolls': function(){
    return Polls.find().count();
  }
});
Template.pollForm.events({

  // handle the form submission
  'submit form': function(event) {

    // stop the form from submitting
    event.preventDefault();
    var question = $('[name="question"]').val();
    

    // get the data we need from the form
    var newPoll = {
      question: event.target.question.value,
      choices: [
        {  text: event.target.choice1.value, votes: 0 },
        {  text: event.target.choice2.value, votes: 0 },
        {  text: event.target.choice3.value, votes: 0 }
      ]
    };    
    
    // attach events to our poll template
Template.poll.events({

  // event to handle clicking a choice
  'click .vote': function(event) {

    // prevent the default behavior
    event.preventDefault();

    // get the parent (poll) id
    var pollID = $(event.currentTarget).parent('.poll').data('id');
    var voteID = $(event.currentTarget).data('id');

    // create the incrementing object so we can add to the corresponding vote
    var voteString = 'choices.' + voteID + '.votes';
    var action = {};
    action[voteString] = 1;

    // increment the number of votes for this choice
    Polls.update(
      { _id: pollID }, 
      { $inc: action }
    );

  },
  'click .delete-poll': function(event){
    event.preventDefault();
    var documentId = this._id;
    var confirm = window.confirm("Delete this poll?");
    if(confirm){
      Polls.remove({ _id: documentId });
    }
  }
});
    // create the new poll
    
    Polls.insert(newPoll);
    $('[name="question"]').val('');
  }

});
/* code for Register and Login */
Template.register.events({
  'submit form': function(event){
      event.preventDefault();
      var email = $('[name=email]').val();
      var password = $('[name=password]').val();
      // var currentUser= Meteor.userId();
      Accounts.createUser({
          email: email,
          password: password
      }),
      //function(error){
        //if(error){
          //console.log(error.reason); // Output error if registration fails
      //} else {
          
          //Router.go("user"); // Redirect user if registration succeeds
      //}
      //}
      Router.go('user');
  }
});
Template.navigation.events({
  'click .logout': function(event){
      event.preventDefault();
      Meteor.logout();
      Router.go('home');
  }
});
Template.login.events({
  'submit form': function(event){
      event.preventDefault();
      var email = $('[name=email]').val();
      var password = $('[name=password]').val();
      Meteor.loginWithPassword(email, password, function(error){
        if(error){
          console.log(error.reason);
          } else {
            
          Router.go("user");
      }
      });
  }
});

UI.registerHelper('indexedArray', function(context, options) {
  if (context) {
    return context.map(function(item, index) {
      item._index = index;
      return item;
    });
  }
});
/* rendering routes for iron router */
Router.route('/', function () {
  this.render('home');  
},{
    name: 'home'
});

Router.route('/register', function () {
  this.render('register');  
},{
    name: 'register'
});
Router.route('/login', function () {
  this.render('login');  
},{
    name: 'login'
});
Router.route('/user', function () {
  this.render('user');  
},{
    name: 'user'
});
